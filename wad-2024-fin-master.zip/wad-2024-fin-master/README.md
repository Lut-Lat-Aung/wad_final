# Stock App
Define variables in `.env`, see `env-example`
